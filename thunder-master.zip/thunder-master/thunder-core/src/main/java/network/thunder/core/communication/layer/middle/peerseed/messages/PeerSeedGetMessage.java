package network.thunder.core.communication.layer.middle.peerseed.messages;

public class PeerSeedGetMessage implements PeerSeedMessage {
    @Override
    public void verify () {

    }

    @Override
    public String toString () {
        return "PeerSeedGetMessage{}";
    }
}
