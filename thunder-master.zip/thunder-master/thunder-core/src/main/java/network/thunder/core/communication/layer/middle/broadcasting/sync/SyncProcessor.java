package network.thunder.core.communication.layer.middle.broadcasting.sync;

import network.thunder.core.communication.layer.Processor;

public abstract class SyncProcessor extends Processor {
}
