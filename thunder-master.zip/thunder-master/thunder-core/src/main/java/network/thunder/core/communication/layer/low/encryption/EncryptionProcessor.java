package network.thunder.core.communication.layer.low.encryption;

import network.thunder.core.communication.layer.Processor;

public abstract class EncryptionProcessor extends Processor {
}
