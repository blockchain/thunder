package network.thunder.core.helper.callback;

public class SyncListener {
    public void onSegmentSynced (int segment) {

    }

    public void onSyncFinished () {

    }

    public void onSyncFailed () {

    }
}
