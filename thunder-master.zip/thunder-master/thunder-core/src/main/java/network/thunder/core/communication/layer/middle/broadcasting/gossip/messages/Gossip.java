package network.thunder.core.communication.layer.middle.broadcasting.gossip.messages;

import network.thunder.core.communication.layer.Message;

public interface Gossip extends Message {
}
