package network.thunder.core.communication.layer.high.payments;

public interface OnionEncrypter {

}
