package network.thunder.core.communication.layer.low.encryption.messages;

import network.thunder.core.communication.layer.Message;

public interface Encryption extends Message {
}
