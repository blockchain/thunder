package network.thunder.core.communication.layer.middle.broadcasting.sync;

public interface SyncClient {
    void syncSegment (int segment);
}
