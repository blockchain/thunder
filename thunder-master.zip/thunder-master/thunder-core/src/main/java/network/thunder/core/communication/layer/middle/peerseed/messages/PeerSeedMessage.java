package network.thunder.core.communication.layer.middle.peerseed.messages;

import network.thunder.core.communication.layer.Message;

public interface PeerSeedMessage extends Message {
}
