package network.thunder.core.communication;

public interface Connection {
    void close ();
}
