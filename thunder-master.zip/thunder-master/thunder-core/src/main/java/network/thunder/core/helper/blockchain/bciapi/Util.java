package network.thunder.core.helper.blockchain.bciapi;

public class Util {
    public static final int SATOSHI_IN_BTC = 100000000;
}
