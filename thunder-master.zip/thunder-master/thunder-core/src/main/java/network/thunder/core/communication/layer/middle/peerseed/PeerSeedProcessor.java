package network.thunder.core.communication.layer.middle.peerseed;

import network.thunder.core.communication.layer.Processor;

public abstract class PeerSeedProcessor extends Processor {
    public static final int PEERS_TO_SEND = 100;
}
