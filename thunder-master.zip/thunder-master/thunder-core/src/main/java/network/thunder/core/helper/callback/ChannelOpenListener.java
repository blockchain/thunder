package network.thunder.core.helper.callback;

import network.thunder.core.helper.callback.results.Result;

public class ChannelOpenListener extends ConnectionListener {

    public void onStart (Result result) {

    }

    public void onFinished (Result result) {

    }
}
