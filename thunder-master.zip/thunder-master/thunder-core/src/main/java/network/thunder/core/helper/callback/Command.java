package network.thunder.core.helper.callback;

public interface Command {
    void execute ();
}
