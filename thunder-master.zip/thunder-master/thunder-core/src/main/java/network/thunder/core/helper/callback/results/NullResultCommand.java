package network.thunder.core.helper.callback.results;

import network.thunder.core.helper.callback.ResultCommandExt;

public class NullResultCommand extends ResultCommandExt {

}
