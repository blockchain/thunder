package network.thunder.core.communication.layer.low.authentication;

import network.thunder.core.communication.layer.Processor;

public abstract class AuthenticationProcessor extends Processor {

}
