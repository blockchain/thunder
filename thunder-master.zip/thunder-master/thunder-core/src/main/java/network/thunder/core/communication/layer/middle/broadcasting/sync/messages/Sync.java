package network.thunder.core.communication.layer.middle.broadcasting.sync.messages;

import network.thunder.core.communication.layer.Message;

public interface Sync extends Message {
}
