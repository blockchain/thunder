package network.thunder.core.communication.layer;

public interface FailureMessage extends Message {
    String getFailure ();
}
