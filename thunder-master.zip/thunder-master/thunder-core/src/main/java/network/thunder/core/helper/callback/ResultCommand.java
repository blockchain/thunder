package network.thunder.core.helper.callback;

import network.thunder.core.helper.callback.results.Result;

public interface ResultCommand {
    void execute (Result result);
}
