package network.thunder.core.communication.layer.high.channel.close;

import network.thunder.core.communication.layer.AuthenticatedProcessor;

public abstract class LNCloseProcessor extends AuthenticatedProcessor {

}
