package network.thunder.core.communication.layer.high.payments.messages;

import network.thunder.core.communication.layer.Message;

public interface LNPayment extends Message {
}
