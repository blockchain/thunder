package network.thunder.core.helper.callback.results;

public interface Result {

    boolean wasSuccessful();

    String getMessage();
}
